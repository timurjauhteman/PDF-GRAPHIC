'use client';

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, Database, Webhook, MonitorPlay, CheckCircle2, ChevronRight, Download } from 'lucide-react';

type ProcessState = 'idle' | 'searching' | 'n8n_processing' | 'rendering_pdf' | 'caching' | 'done';

interface Step {
  status: ProcessState;
  message: string;
  detail?: string;
  url?: string;
}

export default function Home() {
  const [topic, setTopic] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState<Step | null>(null);
  const [history, setHistory] = useState<Step[]>([]);
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setIsProcessing(true);
    setHistory([]);
    setCurrentStep({ status: 'searching', message: 'Inisiasi...' });

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic }),
      });

      if (!response.body) throw new Error('No readable stream');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunks = decoder.decode(value).split('\n\n');
        for (const chunk of chunks) {
          if (chunk.trim().startsWith('data: ')) {
            const dataStr = chunk.replace('data: ', '').trim();
            if (dataStr) {
              const data = JSON.parse(dataStr) as Step;
              setCurrentStep(data);
              setHistory(prev => [...prev, data]);
              
              if (data.status === 'done') {
                setIsProcessing(false);
              }
            }
          }
        }
      }
    } catch (error) {
      console.error(error);
      setIsProcessing(false);
    }
  };

  const getIcon = (status: ProcessState) => {
    switch (status) {
      case 'searching': return <Database className="w-5 h-5 text-blue-400" />;
      case 'n8n_processing': return <Webhook className="w-5 h-5 text-purple-400" />;
      case 'rendering_pdf': return <MonitorPlay className="w-5 h-5 text-amber-400" />;
      case 'caching': return <Database className="w-5 h-5 text-teal-400" />;
      case 'done': return <CheckCircle2 className="w-5 h-5 text-green-400" />;
      default: return <FileText className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <main className="min-h-screen p-6 md:p-24 font-sans max-w-6xl mx-auto flex flex-col gap-12">
      <header className="space-y-4 text-center md:text-left">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 text-sm font-medium mb-4">
          <Database className="w-4 h-4" />
          RAG + Antigravity Engine
        </div>
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400">
          Personalized PDF Generator
        </h1>
        <p className="text-muted-foreground text-lg max-w-2xl text-center md:text-left">
          Sistem Headless Rendering yang terintegrasi dengan n8n webhooks dan Contextual Database Anda untuk menghasilkan resume kurva ekonomi yang presisi.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Input Form Panel */}
        <section className="glass-panel p-8 rounded-2xl flex flex-col gap-6 h-fit border border-white/5 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-32 bg-blue-500/5 blur-3xl rounded-full -mr-16 -mt-16 group-hover:bg-blue-500/10 transition-colors"></div>
          
          <div>
            <h2 className="text-2xl font-semibold text-white mb-2 relative z-10 flex items-center gap-2">
              <FileText className="w-6 h-6 text-blue-400" />
              Materi Ekonomi Baru
            </h2>
            <p className="text-zinc-400 text-sm relative z-10">Masukkan model atau konsep untuk diproses oleh jaringan RAG kami.</p>
          </div>

          <form onSubmit={handleGenerate} className="flex flex-col gap-4 relative z-10">
            <div className="space-y-2">
              <label htmlFor="topic" className="text-sm font-medium text-zinc-300">
                Topik / Keyword Konsep
              </label>
              <input
                id="topic"
                type="text"
                placeholder="Contoh: Romer Growth Model, IS-LM Curve..."
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                disabled={isProcessing}
                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
              />
            </div>
            
            <button
              type="submit"
              disabled={isProcessing || !topic.trim()}
              className="mt-2 text-white font-medium px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 flex items-center justify-center gap-2 glow-button disabled:hover:after:opacity-0 active:scale-[0.98] transition-transform"
            >
              {isProcessing ? (
                <>
                  <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Memproses...</span>
                </>
              ) : (
                <>
                  Generate PDF <ChevronRight className="w-4 h-4 ml-1" />
                </>
              )}
            </button>
          </form>
        </section>

        {/* Real-time Processing Logs Panel */}
        <section className="glass-panel p-8 rounded-2xl border border-white/5 bg-black/20 flex flex-col min-h-[400px]">
          <h3 className="text-lg font-medium text-zinc-300 mb-6 flex items-center justify-between border-b border-white/10 pb-4">
            <span className="flex items-center gap-2">
              <Webhook className="w-5 h-5" /> 
              Telemetry Pipeline
            </span>
            {isProcessing && (
              <span className="flex items-center gap-2 text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded-md mt-1">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                </span>
                Live
              </span>
            )}
          </h3>

          <div className="flex-1 overflow-y-auto pr-2 space-y-4">
            {history.length === 0 && !isProcessing && (
              <div className="h-full flex flex-col items-center justify-center text-zinc-600 gap-3">
                <MonitorPlay className="w-10 h-10 opacity-20" />
                <p className="text-sm">Menunggu instruksi komputasi...</p>
              </div>
            )}

            <AnimatePresence>
              {history.map((log, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  className="flex gap-4 p-4 rounded-xl bg-white/5 border border-white/5"
                >
                  <div className="flex-shrink-0 mt-1">{getIcon(log.status)}</div>
                  <div className="flex flex-col gap-1 w-full">
                    <p className="text-sm text-zinc-200 font-medium">{log.message}</p>
                    {log.detail && (
                      <div className="text-xs bg-black/40 text-green-400/80 p-2 rounded-md font-mono overflow-x-auto whitespace-pre">
                        {'>'} {log.detail}
                      </div>
                    )}
                    {log.url && (
                      <button className="mt-2 w-fit inline-flex items-center gap-2 text-xs font-semibold px-3 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors border border-white/5">
                        <Download className="w-3 h-3" /> Download Result_v1.pdf
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            <div ref={logsEndRef} />
          </div>
        </section>
      </div>
    </main>
  );
}
