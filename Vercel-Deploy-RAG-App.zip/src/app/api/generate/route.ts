import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import crypto from 'crypto';

export async function POST(req: Request) {
  const { topic } = await req.json();

  const stream = new ReadableStream({
    async start(controller) {
      const sendEvent = (data: object) => {
        controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(data)}\n\n`));
      };

      try {
        // ========== 1. SUPABASE RAG RETRIEVAL ==========
        sendEvent({ 
          status: "searching", 
          message: `Mengambil RAG konteks dari Supabase untuk materi: "${topic}"...`, 
          detail: `supabase.from('materi_ekonomi').select().ilike('judul', '%${topic}%')`
        });
        
        // Coba cari data asli dari tabel materi_ekonomi menggunakan pencarian teks dasar (sebagai representasi RAG)
        // Di sistem RAG sebenarnya, panggil supabase.rpc('match_materi', { query_embedding, match_threshold, match_count })
        const { data: materiData, error: dbError } = await supabase
          .from('materi_ekonomi')
          .select('*')
          .ilike('judul', `%${topic}%`)
          .limit(1);
          
        let contextText = "Ini adalah placeholder context karena database Supabase URL belum dilampirkan atau data kosong.";
        let materiId = null;

        if (materiData && materiData.length > 0) {
          contextText = materiData[0].konten_materi;
          materiId = materiData[0].id;
        }
        await new Promise(resolve => setTimeout(resolve, 800));

        // ========== 2. BUILD HTML TEMPLATE WITH CONTEXT (Vibe to Chart.js) ==========
        sendEvent({ 
          status: "n8n_processing", 
          message: `Menyiapkan Canvas Chart.js dari template_kurva...`, 
          detail: "Injecting context:\n" + contextText.substring(0, 50) + "..."
        });

        // Contoh payload HTML yang diinjeksikan materi catatan RAG untuk dirender jadi kurva
        const processedHtml = `
          <!DOCTYPE html>
          <html>
          <head>
              <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
              <style>
                body { font-family: 'Inter', sans-serif; padding: 40px; color: #111; }
                .report-header { font-size: 28px; font-weight: bold; margin-bottom: 5px; color: #1e3a8a; }
                .report-context { font-size: 14px; background: #f1f5f9; padding: 15px; border-left: 4px solid #3b82f6; margin-bottom: 30px; }
              </style>
          </head>
          <body>
              <div class="report-header">Ringkasan Ekonomi: ${topic}</div>
              <div class="report-context">${contextText}</div>
              <canvas id="myChart" width="800" height="400"></canvas>
              <script>
                  // Render kurva berdasarkan Data Ekonomi
                  const ctx = document.getElementById('myChart').getContext('2d');
                  new Chart(ctx, {
                      type: 'line',
                      data: {
                          labels: ['T1', 'T2', 'T3', 'T4', 'T5'],
                          datasets: [{
                              label: 'Economic Output / Y',
                              data: [12, 19, 21, 25, 29],
                              borderColor: 'rgba(59, 130, 246, 1)',
                              borderWidth: 3,
                              tension: 0.4
                          }]
                      },
                      options: { animation: false } // Matikan animasi untuk memastikan render seketika di PDF
                  });
              </script>
          </body>
          </html>
        `;
        await new Promise(resolve => setTimeout(resolve, 800));

        // ========== 3. SEND TO ANTIGRAVITY ENGINE (PDF/PPT Headless Render) ==========
        sendEvent({ 
          status: "rendering_pdf", 
          message: "Menembak Engine Vercel / Antigravity untuk Konversi... (wait_until: networkidle0)",
          detail: "Mengirim payload { html, options: { waitFor: '#myChart' } } ke print engine"
        });

        // Di sinilah API external untuk nge-print dipanggil, misalnya /api/print atau Browserless.io
        // const pdfResponse = await fetch('https://antigravity-print-engine.url', { 
        //   method: 'POST', body: JSON.stringify({ html: processedHtml, options: { waitUntil: 'networkidle0', waitFor: '#myChart' } }) 
        // });
        
        // Simulasikan file binary Buffer.from(pdfResponse.arrayBuffer()) 
        const mockBinaryPdf = Buffer.from("mock_pdf_binary_content_" + Date.now()); 
        
        await new Promise(resolve => setTimeout(resolve, 1500));

        // ========== 4. SAVE TO SUPABASE STORAGE & CACHE TABLE ==========
        sendEvent({ 
          status: "caching", 
          message: "Cache hit! Menyimpan binary PDF ke Supabase Storage...", 
          detail: "supabase.storage.from('pdfs').upload(...)"
        });

        const fileName = `generated/${crypto.randomUUID()}_${topic.replace(/\\s/g, '_')}.pdf`;
        
        // Upload File ke Storage
        // await supabase.storage.from('pdfs').upload(fileName, mockBinaryPdf, { contentType: 'application/pdf' });
        
        // Simpan Record ke Tabel history_pdf untuk RAG Tracking
        // if (materiId) {
        //   await supabase.from('history_pdf').insert({ materi_id: materiId, storage_path: fileName });
        // }
        // const { data: publicUrl } = supabase.storage.from('pdfs').getPublicUrl(fileName);

        await new Promise(resolve => setTimeout(resolve, 1000));

        // ========== 5. FINAL RESULT ==========
        const dummyPdfUrl = `https://your-supabase-url.co/storage/v1/object/public/pdfs/${fileName}`;

        sendEvent({ 
          status: "done", 
          message: "PDF berhasil dibuat dan dicache di Supabase!", 
          url: dummyPdfUrl
        });
        
        controller.close();
      } catch (err: any) {
        sendEvent({ status: "done", message: "Kesalahan internal terjadi: " + err.message });
        controller.close();
      }
    }
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive'
    }
  });
}
